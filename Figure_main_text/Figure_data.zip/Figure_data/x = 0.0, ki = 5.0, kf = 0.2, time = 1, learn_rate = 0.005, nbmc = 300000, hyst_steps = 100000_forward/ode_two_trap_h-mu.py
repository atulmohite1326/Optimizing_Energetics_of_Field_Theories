import numpy as np
from scipy.integrate import odeint
import matplotlib.pyplot as plt
import os
import shutil as sh
import pickle
import sys
import multiprocessing as mp
import time as ti
import multiprocessing as mp
import datetime as dat
from multiprocessing.pool import ThreadPool

i = 1
try:
    f_freq = float(sys.argv[i]); i+=1                  # difference between ki_0 and kf_0
    ki_0 = float(sys.argv[i]); i+=1               # Number of lattice sites
    kf_0 = float(sys.argv[i]); i+=1               # Initial uniform density
    learn_rate = float(sys.argv[i]); i+=1         # Learning rate for SGD MC
    hyst_steps = int(sys.argv[i]); i+=1         # Number of hysterysis steps for SD
    nbmc = 2000000                                # Number of MC for SD
    time = 1
except:
    f_freq = 0.5
    ki_0 = np.float(5.0)
    kf_0 = np.float(0.2222)
    time = 1
    learn_rate = 0.01
    nbmc = 50
    hyst_steps = 10
    print('No input given. Taking default values.')

# x = 0.5
#
# ki_0 = np.float(5.0)
# kf_0 = np.float(1.0)

ki_1 = np.float(ki_0 + f_freq*f_freq)
kf_1 = np.float(kf_0 + f_freq*f_freq)

# gamma_matrix = np.asarray([0.05, 0.1, 0.15, 0.2, 0.3, 0.4, 0.5, 0.6, 0.8, 1.0, 1.1, 1.2, 1.3, 1.4, 1.6, 2.0, 2.5, 4.0])

# gamma_matrix = np.asarray([1.0, 1.1, 1.2, 1.3, 1.4, 1.5, 1.6, 1.7, 1.8, 1.9, 2.0, 2.1, 2.2, 2.3, 2.4, 2.5, 2.6, 2.7, 2.8, 2.9, 3.0,3.2, 3.4, 3.6, 3.8, 4.0, 4.5])
gamma_matrix = np.asarray([0.002, 0.004, 0.007, 0.01, 0.02, 0.04, 0.05, 0.06, 0.07, 0.08, 0.09, 0.1, 0.12, 0.14, 0.16, 0.18, 0.2, 0.22, 0.24, 0.26, 0.28, 0.3, 0.4, 0.5, 0.6, 0.8, 1.0])

# al = np.asarray([0.0, 0.05, 0.15, 0.25, 0.3, 0.32, 0.34, 0.36, 0.38, 0.4, 0.43, 0.47, 0.5, 0.53, 0.56, 0.58, 0.6, 0.62, 0.64, 0.7, 0.85, 1.0])

# al = np.asarray([0.0, 0.05, 0.15, 0.22, 0.27, 0.3, 0.32, 0.34, 0.36, 0.37, 0.38, 0.39, 0.4, 0.41, 0.42, 0.43, 0.44, 0.45, 0.46, 0.48, 0.5, 0.52, 0.54, 0.56, 0.58, 0.6, 0.65, 0.7, 0.85, 1.0])
al = np.asarray([0.0, 0.2, 0.4, 0.50, 0.51,  0.52, 0.53, 0.54, 0.55, 0.56, 0.57, 0.58, 0.59, 0.6, 0.61, 0.62, 0.63, 0.64, 0.65, 0.66, 0.84, 1.0])
# al = np.asarray([1.0])

# hyst_steps_mat = np.asarray([1e3, 2e3, 4e3, 6e3, 8e3, 1e4, 2e4, 3e4, 4e4, 5e4])

class SingleTrap:
    def __init__(self, k_i, k_f, noise_str):
        self.ki = k_i
        self.kf = k_f
        self.L = noise_str
        self.result_list = []
        self.alpha_list = []
        self.output = []
        self.output.append([])
        self.output.append([])
        self.output.append([])
        self.output.append([])

    def simulate_pareto_single_trap(self):
        output = []
        output.append([])
        output.append([])
        output.append([])
        output.append([])
        prt_0 = np.random.uniform(self.L * self.ki, self.L * self.kf, time * 100 + 1)
        for i in range(len(al)):
            # prt_0 = np.random.uniform(self.ki, self.kf, 100 + 1)
            # prt_0 = np.linspace(self.L*self.ki, self.L*self.kf, 100 + 1)
            if i == 0:
                mc_steps = nbmc
            else:
                mc_steps = hyst_steps
            alpha = al[i]
            work, std_dev, prtcl0, cost_func = self.monte_carlo(prt_0, alpha, mc_steps) # mean work, standard deviation, optimum protocol
            output[0].append(work)
            output[1].append(std_dev)
            output[2].append(prtcl0)
            output[3].append(cost_func)
            prt_0 = prtcl0
        return output

    def post_run_processing(self):
        serial_array = np.argsort(np.array(self.alpha_list))
        print('CHECKPOINT POST_RUN_PROCESS----1')
        for i in serial_array:
            self.output[0].append(self.result_list[i][0])
            self.output[1].append(self.result_list[i][1])
            self.output[2].append(self.result_list[i][2])
            self.output[3].append(self.result_list[i][3])
        print('CHECKPOINT POST_RUN_PROCESS----2')

    def multiprocess_simulate_pareto_run(self):
        # pool = mp.Pool(mp.cpu_count())
        pool = ThreadPool(mp.cpu_count())
        print('CHECKPOINT MULTI_PROCESS----1')
        for l1 in al:
            prt_0 = np.random.uniform(self.ki, self.kf, time * 100 + 1)
            print(l1)
            pool.apply_async(self.monte_carlo, args=(l1), callback=self.save_result)
        # [pool.apply(simulate_single_trap_class, args=(directory, l1)) for l1 in gamma_matrix]
        print('CHECKPOINT MULTI_PROCESS----2')
        pool.close()
        pool.join()
        print(mp.cpu_count())
        print(pool)
        print(' IMPLEMENTED WITH MULTI-PROCESS ')
        self.post_run_processing()

    def save_result(self, result):
        real_result, alpha = result
        print('THE', real_result.shape)
        print('THE', alpha.shape)
        self.result_list.append(real_result)
        self.alpha_list.append(alpha)

    def monte_carlo(self, initial_protocol, alp, mc_steps):
        # protocol = np.random.uniform(self.ki, self.kf, 100 + 1)
        protocol = initial_protocol.copy()
        previous_cost = 1e10
        # nbmc = 120000
        # protocol_time = np.zeros((nbmc, 101), dtype=np.complex128)
        protocol_time = np.zeros((time * 100 + 1), dtype=np.complex128)
        mc = 0
        last_mc = 0
        alpha = alp
        # gradient = 0.01*np.ones((101,), dtype=int)
        for i in range(mc_steps):
            # learn_rate = 1/(i/100 + 1)
            # change random point of the protocol with a gaussian increment
            j = np.random.randint(0, time * 100 + 1)
            protocol_new = protocol.copy()
            protocol_new[j] = protocol_new[j] + learn_rate*(self.ki - self.kf)*self.L*np.random.normal(0, 1)
            protocol_new = abs(protocol_new)
            # protocol_new[j] = protocol_new[j] + learn_rate*(self.ki - self.kf)*np.random.normal(0, 1)
            # dx = np.random.normal(0, self.ki)
            # protocol_new[j] = protocol_new[j] + gradient[j]*dx
            # print(j)
            #solve ODE
            solution = self.solve_ode(protocol_new)
            #Compute work and variance and the cost function
            work, var = self.work_and_variance(solution)
            current_cost = self.cost_fn(work, var, alpha)
            # print('The cost function is', current_cost)
            # print('The cost function is', previous_cost)
            if current_cost < previous_cost:
                # accept the protocol change
                # gradient[j] = (current_cost - previous_cost) / dx
                previous_cost = current_cost
                protocol = protocol_new.copy()
                mc = mc + 1
                last_mc = i
            # protocol_time[i] = protocol.copy()
            protocol_time = protocol.copy()
        # print('The number of MC updates', mc)
        # print('The last MC update', last_mc)
        # print(' The ALPHA is', alpha)
        # print(' The MOBILITY is', self.L)
        # plot_protocol(protocol_time)
        work, var = self.work_and_variance(solution)
        std = np.sqrt(var - work*work)
        return work, std, protocol_time, previous_cost

    def dPdt(self, P, t, *args):
        w, x_2, w_2, x_2w, x0_2w, x_2x0_2, x_4, prtcl = P
        prtcl_ini, prtcl_final, initial_correl = args
        # prtcl_dot = np.float(100.0 * (prtcl_final - prtcl_ini))
        # dwdt = np.float(0.5 * prtcl_dot * x_2 * self.L)
        # dx_2dt = np.float(-2.0 * prtcl * x_2 * self.L + 2.0 * self.L)
        # dw_2dt = np.float(prtcl_dot * x_2w * self.L)
        # dx_2wdt = np.float(2.0 * w * self.L + 0.5 * prtcl_dot * x_4 * self.L - 2.0 * prtcl * x_2w * self.L)
        # dx0_2wdt = np.float(0.5 * prtcl_dot * x_2x0_2 * self.L)
        # dx_2x0_2dt = np.float(-2.0 * prtcl * x_2x0_2 * self.L + 2.0 * initial_correl * self.L)
        # dx_4dt = np.float(-4.0 * prtcl * x_4 * self.L + 12.0 * x_2 * self.L)
        # dprodt = np.float(100.0 * (prtcl_final - prtcl_ini))
        prtcl_dot = np.float(100.0 * (prtcl_final - prtcl_ini))
        dwdt = np.float(0.5 * prtcl_dot * x_2)
        dx_2dt = np.float(-2.0 * prtcl * x_2 + 2.0 * self.L)
        dw_2dt = np.float(prtcl_dot * x_2w)
        dx_2wdt = np.float(2.0 * w * self.L + 0.5 * prtcl_dot * x_4 - 2.0 * prtcl * x_2w)
        dx0_2wdt = np.float(0.5 * prtcl_dot * x_2x0_2)
        dx_2x0_2dt = np.float(-2.0 * prtcl * x_2x0_2 + 2.0 * initial_correl * self.L)
        dx_4dt = np.float(-4.0 * prtcl * x_4 + 12.0 * x_2 * self.L)
        dprodt = np.float(100.0 * (prtcl_final - prtcl_ini))
        return dwdt, dx_2dt, dw_2dt, dx_2wdt, dx0_2wdt, dx_2x0_2dt, dx_4dt, dprodt

    def solve_ode(self, given_protocol):
        prt = given_protocol
        # prt = np.random.uniform(0.5, 1, 100 + 1)
        t2 = np.linspace(0, 0.01, 10 + 1)
        w0 = 0.0
        x_20 = 1.0/self.ki
        w_20 = 0.0
        x_2w0 = 0.0
        x0_2w0 = 0.0
        x_2x0_20 = 3.0/(self.ki*self.ki)
        x_40 = 3.0/(self.ki*self.ki)
        prtcl0 = prt[0]
        temp_sol2 = w0, x_20, w_20, x_2w0, x0_2w0, x_2x0_20, x_40, prtcl0
        parameters = []
        for i in range(time * 100):
            parameters.append((prt[i], prt[i + 1], np.float(1/self.ki)))
        for i in range(time * 100):
            temp_sol3 = odeint(self.dPdt, temp_sol2, t2, args=parameters[i])
            # print('The shape of the temp_sol3', temp_sol3.shape)
            # print('The shape of the temp_sol3', temp_sol2.shape)
            if i == 0:
                sol2 = temp_sol3.copy()
            else:
                sol2 = np.vstack((sol2, temp_sol3[1:11, :]))
                # print('The shape of the temp_sol3', temp_sol3[1:11, :].shape)
            temp_sol2 = tuple(temp_sol3[10, :])
        return sol2

    def work_and_variance(self, input):
        sh = input.shape
        delta_k0 = input[0, 7] - self.ki
        delta_kt = self.kf - input[sh[0]-1, 7]
        work = input[sh[0]-1, 0] + 0.5*delta_k0*input[0, 1] + 0.5*delta_kt*input[sh[0]-1, 1]
        variance = input[sh[0]-1, 2] + delta_k0*input[sh[0]-1, 4] + delta_kt*input[sh[0]-1, 3] + 0.25*(delta_k0*delta_k0*input[0, 6] + 2*delta_k0*delta_kt*input[sh[0]-1, 5] + delta_kt*delta_kt*input[sh[0]-1, 6])
        return work, variance

    def cost_fn(self, work, variance, a):
        standard_deviation = np.sqrt(variance - work*work)
        return a*work + (1 - a)*standard_deviation

    def __del__(self):
        print("Object deleted")


# class DoubleTrap:
#     def __init__(self, ki_0, kf_0, ki_1, kf_1):
#         self.ki_0 = ki_0
#         self.kf_0 = kf_0
#         self.ki_1 = ki_1
#         self.kf_1 = kf_1
#
#     def dPdt(self, P, t, *args):
#         w, x_2, w_2, x_2w, x0_2w, x_2x0_2, x_4, prtcl = P
#         prtcl_ini, prtcl_final, initial_correl = args
#         prtcl_dot = np.float(100.0*(prtcl_final - prtcl_ini))
#         dwdt = np.float(0.5*prtcl_dot*x_2)
#         dx_2dt = np.float(-2.0*prtcl*x_2 + 2.0)
#         dw_2dt = np.float(prtcl_dot*x_2w)
#         dx_2wdt = np.float(2.0*w + 0.5*prtcl_dot*x_4 - 2.0*prtcl*x_2w)
#         dx0_2wdt = np.float(0.5*prtcl_dot*x_2x0_2)
#         dx_2x0_2dt = np.float(-2.0*prtcl*x_2x0_2 + 2.0*initial_correl)
#         dx_4dt = np.float(-4.0*prtcl*x_4 + 12.0*x_2)
#         dprodt = np.float(100.0*(prtcl_final - prtcl_ini))
#         return dwdt, dx_2dt, dw_2dt, dx_2wdt, dx0_2wdt, dx_2x0_2dt, dx_4dt, dprodt
#
#     def solve_ode_0(self, given_protocol):
#         prt = given_protocol
#         # prt = np.random.uniform(0.5, 1, 100 + 1)
#         t2 = np.linspace(0, 0.01 * time, 10 + 1)
#         w0 = 0.0
#         x_20 = 1.0/self.ki_0
#         w_20 = 0.0
#         x_2w0 = 0.0
#         x0_2w0 = 0.0
#         x_2x0_20 = 3.0/(self.ki_0*self.ki_0)
#         x_40 = 3.0/(self.ki_0*self.ki_0)
#         prtcl0 = prt[0]
#         temp_sol2 = w0, x_20, w_20, x_2w0, x0_2w0, x_2x0_20, x_40, prtcl0
#         parameters = []
#         # print(' KI for zeroth harmonic oscillator is ', 1.0/self.ki_0)
#         # print(' KF for zeroth harmonic oscillator is ', 1.0/self.kf_0)
#         for i in range(100):
#             parameters.append((prt[i], prt[i + 1], np.float(1/self.ki_0)))
#         for i in range(100):
#             temp_sol3 = odeint(self.dPdt, temp_sol2, t2, args=parameters[i])
#             # print('The shape of the temp_sol3', temp_sol3.shape)
#             # print('The shape of the temp_sol3', temp_sol2.shape)
#             if i == 0:
#                 sol2 = temp_sol3.copy()
#                 print(self.ki_0, self.kf_0)
#             else:
#                 sol2 = np.vstack((sol2, temp_sol3[1:11, :]))
#                 # print('The shape of the temp_sol3', temp_sol3[1:11, :].shape)
#             temp_sol2 = tuple(temp_sol3[10, :])
#         return sol2
#
#     def solve_ode_1(self, given_protocol):
#         prt = given_protocol
#         # prt = np.random.uniform(0.5, 1, 100 + 1)
#         t2 = np.linspace(0, 0.01 * time, 10 + 1)
#         w0 = 0.0
#         x_20 = 1.0/self.ki_1
#         w_20 = 0.0
#         x_2w0 = 0.0
#         x0_2w0 = 0.0
#         x_2x0_20 = 3.0/(self.ki_1*self.ki_1)
#         x_40 = 3.0/(self.ki_1*self.ki_1)
#         prtcl0 = prt[0]
#         temp_sol2 = w0, x_20, w_20, x_2w0, x0_2w0, x_2x0_20, x_40, prtcl0
#         parameters = []
#         print(' KI for second harmonic oscillator is ', 1.0 / self.ki_1)
#         print(' KF for second harmonic oscillator is ', 1.0 / self.kf_1)
#         for i in range(100):
#             parameters.append((prt[i], prt[i + 1], np.float(1/self.ki_1)))
#         for i in range(100):
#             temp_sol3 = odeint(self.dPdt, temp_sol2, t2, args=parameters[i])
#             # print('The shape of the temp_sol3', temp_sol3.shape)
#             # print('The shape of the temp_sol3', temp_sol2.shape)
#             if i == 0:
#                 sol2 = temp_sol3.copy()
#                 print(self.ki_1, self.kf_1)
#             else:
#                 sol2 = np.vstack((sol2, temp_sol3[1:11, :]))
#                 # print('The shape of the temp_sol3', temp_sol3[1:11, :].shape)
#             temp_sol2 = tuple(temp_sol3[10, :])
#         return sol2
#
#     def monte_carlo_1(self, initial_protocol0, initial_protocol1, alp):
#         protocol0 = initial_protocol0.copy()
#         protocol1 = initial_protocol1.copy()
#         previous_cost = 40000
#         nbmc = 300
#         # protocol_time = np.zeros((nbmc, 101), dtype=np.complex128)
#         protocol_time0 = np.zeros((101), dtype=np.complex128)
#         protocol_time1 = np.zeros((101), dtype=np.complex128)
#         mc_0 = 0
#         mc_1 = 0
#         last_mc = 0
#         # work0, var0 = work_and_variance_0(protocol0)
#         # work1, var1 = work_and_variance_1(protocol1)
#         solution0 = self.solve_ode_0(protocol0)
#         work0, var0 = self.work_and_variance_0(solution0)
#         solution1 = self.solve_ode_1(protocol1)
#         work1, var1 = self.work_and_variance_1(solution1)
#         # work0, var0 = 100.0, 10000.0
#         # work1, var1 = 100.0, 10000.0
#         alpha = alp
#         # adpt_step_size = np.random.uniform(1, 1.01, 100 + 1)
#         for i in range(nbmc):
#             print(i)
#             coin_flip = np.random.randint(0, 1000) % 2
#             print(' The coin flip is', coin_flip)
#             if coin_flip == 0:
#                 j = np.random.randint(0, 101)
#                 protocol_new = protocol0.copy()
#                 protocol_new[j] = protocol_new[j] + 0.01*np.random.normal(0, self.ki_0)
#                 solution0 = self.solve_ode_0(protocol_new)
#                 work0, var0 = self.work_and_variance_0(solution0)
#                 current_cost = self.cost_fn1(work0, var0, work1, var1, alpha)
#                 print('The cost function is', current_cost)
#                 print('The cost function is', previous_cost)
#                 if current_cost < previous_cost:
#                     # accept the protocol change
#                     previous_cost = current_cost
#                     protocol0 = protocol_new.copy()
#                     mc_0 = mc_0 + 1
#                     last_mc = i
#                 protocol_time0 = protocol0.copy()
#             else:
#                 j = np.random.randint(0, 101)
#                 protocol_new = protocol1.copy()
#                 protocol_new[j] = protocol_new[j] + 0.01*np.random.normal(0, self.ki_1)
#                 solution1 = self.solve_ode_1(protocol_new)
#                 work1, var1 = self.work_and_variance_1(solution1)
#                 current_cost = self.cost_fn1(work0, var0, work1, var1, alpha)
#                 print('The cost function is', current_cost)
#                 print('The cost function is', previous_cost)
#                 if current_cost < previous_cost:
#                     # accept the protocol change
#                     previous_cost = current_cost
#                     protocol1 = protocol_new.copy()
#                     mc_1 = mc_1 + 1
#                     last_mc = i
#                 protocol_time1 = protocol1.copy()
#             # if i == nbmc-1:
#             #     print(' The work and the variance are ', work0, var0, work1, var1)
#             #     print(' The zeroth mode standard deviation is ', np.sqrt(var0 - work0*work0))
#             #     print(' The second mode standard deviation is ', np.sqrt(var1 - work1 * work1))
#             #     print(' The cost function is ', current_cost)
#             #     print(' The alpha is', alpha)
#             # t_total = np.linspace(0, 1, 100 + 1)
#             # plt.plot(t_total, protocol, 'r', label='< Lambda(t) >')
#             # plt.legend(loc='upper left')
#             # plt.xlabel('t')
#             # plt.grid()
#             # plt.show()
#         print('The number of ZEROTH OSCILLATOR MC updates', mc_0)
#         print('The number of SECOND OSCILLATOR MC updates', mc_1)
#         print('The last MC update', last_mc)
#         # plot_protocol(protocol_time0, ki_0)
#         # plot_protocol(protocol_time1, ki_1)
#         work0, var0 = self.work_and_variance_0(solution0)
#         work1, var1 = self.work_and_variance_1(solution1)
#         std = np.sqrt(var0 + var1 - work0*work0 - work1*work1)
#         work = work0 + work1
#         print(' THE NET WORK AND STANDARD DEVIATION ARE ', work, std)
#         return work, std, protocol_time0, protocol_time1
#
#     def simulate_pareto(self):
#         output = []
#         al = np.asarray([0.0, 0.05, 0.1, 0.15, 0.25, 0.4, 0.7, 1.0])
#         output.append([])
#         output.append([])
#         output.append([])
#         output.append([])
#         for i in range(len(al)):
#             prt_0 = np.random.uniform(ki_0, kf_0, 100 + 1)
#             prt_1 = np.random.uniform(ki_1, kf_1, 100 + 1)
#             alpha = al[i]
#             work, std_dev, prtcl0, prtcl1 = self.monte_carlo_1(prt_0, prt_1, alpha)  # mean work, standard deviation, optimum protocol
#             output[0].append(work)
#             output[1].append(std_dev)
#             output[2].append(prtcl0)
#             output[3].append(prtcl1)
#         return output
#
#     def cost_fn1(self, work0, variance0, work1, variance1, a):
#         standard_deviation = np.sqrt(variance0 + variance1 - work1*work1 - work0*work0)
#         return a*(work0+work1) + (1 - a)*standard_deviation
#
#     def work_and_variance_0(self, input):
#         sh = input.shape
#         print(sh)
#         delta_k0 = input[0, 7] - self.ki_0
#         delta_kt = self.kf_0 - input[sh[0]-1, 7]
#         work = input[sh[0]-1, 0] + 0.5*delta_k0*input[0, 1] + 0.5*delta_kt*input[sh[0]-1, 1]
#         variance = input[sh[0]-1, 2] + delta_k0*input[sh[0]-1, 4] + delta_kt*input[sh[0]-1, 3] + 0.25*(delta_k0*delta_k0*input[0, 6] + 2*delta_k0*delta_kt*input[sh[0]-1, 5] + delta_kt*delta_kt*input[sh[0]-1, 6])
#         return work, variance
#
#     def work_and_variance_1(self, input):
#         sh = input.shape
#         delta_k0 = input[0, 7] - self.ki_1
#         delta_kt = self.kf_1 - input[sh[0]-1, 7]
#         work = input[sh[0]-1, 0] + 0.5*delta_k0*input[0, 1] + 0.5*delta_kt*input[sh[0]-1, 1]
#         variance = input[sh[0]-1, 2] + delta_k0*input[sh[0]-1, 4] + delta_kt*input[sh[0]-1, 3] + 0.25*(delta_k0*delta_k0*input[0, 6] + 2*delta_k0*delta_kt*input[sh[0]-1, 5] + delta_kt*delta_kt*input[sh[0]-1, 6])
#         return work, variance


def plot_ode(sol2):
    t_total = np.linspace(0, time, time * 1000 + 1)
    print('Shape of the solution array', sol2.shape)
    plt.plot(t_total, sol2[:, 0], 'r', label='< w(t) >')
    plt.plot(t_total, sol2[:, 1], 'g', label='< X^2(t) >')
    plt.plot(t_total, sol2[:, 2], 'b', label='< w^2(t) >')
    plt.plot(t_total, sol2[:, 3], 'y', label='< X^2 . w(t) >')
    plt.plot(t_total, sol2[:, 4], 'c', label='< X0^2 . w(t) >')
    plt.plot(t_total, sol2[:, 5], 'm', label='< X^2 . X0^2(t) >')
    plt.plot(t_total, sol2[:, 6], 'g', label='< X^4(t) >')
    plt.legend(loc='upper left')
    plt.xlabel('t')
    plt.grid()
    plt.show()


def plot_protocol(protocol_time, ki):
    t_total = np.linspace(0, time, time * 100 + 1)
    # sh = protocol_time.shape
    # for i in range(sh[0]):
    #     plt.plot(t_total, protocol_time[i, :], 'r', label='< w(t) >')
    # plt.plot(t_total, protocol_time[sh[0]-1, :], 'r', label='< Lambda(t) >')
    plt.plot(t_total, protocol_time/ki, 'r', label='< Lambda(t) >')
    # plt.plot(t_total, protocol_time[1, :], 'r', label='< Lambda(t) >')
    plt.legend(loc='upper left')
    plt.xlabel('t')
    plt.grid()
    plt.show()


def plot_pareto_single_trap():
    CHECK_FOLDER = os.path.isdir('Pareto_front')
    if not CHECK_FOLDER:
        os.makedirs('Pareto_front')

    CHECK_FOLDER = os.path.isdir('Pareto_front/Single_trap_change_gamma')
    if not CHECK_FOLDER:
        os.makedirs('Pareto_front/Single_trap_change_gamma')

    n1 = 'k0 = ' + str(ki_0)
    n2 = ', k0 = ' + str(kf_0)
    nt = ', time = ' + str(time)
    folder_name = str(n1 + n2 + nt)
    print(folder_name)

    try:
        os.mkdir('Pareto_front/Single_trap_change_gamma/' + folder_name)
    except OSError as error:
        print(error)

    for i in range(len(gamma_matrix)):
        x = gamma_matrix[i]
        sub_folder_name = 'gamma = ' + str(x)
        try:
            os.mkdir('Pareto_front/Single_trap_change_gamma/' + folder_name + '/' + str(sub_folder_name))
        except OSError as error:
            print(error)

        obj0 = SingleTrap(ki_1, kf_1, x)
        output0 = obj0.simulate_pareto_single_trap()
        dir = 'Pareto_front/Single_trap_change_gamma/' + folder_name + '/' + str(sub_folder_name)
        save_data(output0, 'Pareto_front/Single_trap_change_gamma/' + folder_name + '/' + str(sub_folder_name))
        # plot_output_data(output0, dir)
        plot_data_recursively(output0, dir)


def plot_data_recursively(output, directory, xx):
    work0 = np.asarray(output[0])
    std0 = np.asarray(output[1])
    prtcl0_single = np.asarray(output[2])
    cost_func = np.asarray(output[3])
    t2 = np.linspace(0, time, time * 100 + 1)
    mu = xx
    markers = ['o', 's', 'p', '*', 'h', 'd', 'v', 'X', 's', 'p', '*', 'h', 'd']
    colors = ['r', 'g', 'b', 'y', 'c', 'm']

    print('PRINT, IT WAS HERE')
    # plt.plot(al, cost_func, 'r', label=r'$Cost-function = \mathcal{J}_{\alpha}$')
    # plt.legend(loc='best')
    # plt.xlabel(r'$\alpha $')
    # plt.ylabel(r'$\mathcal{J}_{\alpha}$')
    # plt.grid()
    # plt.savefig(directory + '/cost_function.pdf')
    # plt.clf()

    fig1 = plt.figure()
    fig1.suptitle(r'$\mu = {}$'.format(mu), fontsize=24)
    plt.plot(al, cost_func/mu, '.', label=r'$Cost-function = \mathcal{J}_{\alpha}$')
    # plt.plot(al, cost_func, '.', label=r'$Cost-function = \mathcal{J}_{\alpha}$')
    # plt.title(r'$\mu = {}$.format(mu)', fontsize=20)
    plt.legend(loc='best')
    plt.xlabel(r'$\alpha $', fontsize=24)
    plt.ylabel(r'$\mathcal{J}_{\alpha}$', fontsize=24)
    plt.grid()
    plt.savefig(directory + '/cost_function.pdf')
    plt.clf()

    lines = []
    fig1 = plt.figure()
    fig1.suptitle(r'$\mu = {}$'.format(mu), fontsize=24)
    for i in range(len(al)):
        lines += plt.plot(t2, (prtcl0_single[i]/mu - kf_0)/(ki_0 - kf_0), colors[i % 6], label=r'$\alpha = {}$'.format(al[i]))
        # lines += plt.plot(t2, (prtcl0_single[i] - kf_0) / (ki_0 - kf_0), colors[i % 6], label=r'$\alpha = {}$'.format(al[i]))
    labels = [l.get_label() for l in lines]
    # plt.title(r'$\mu = {}$.format(mu)', fontsize=20)
    plt.xlabel('t', fontsize=24)
    plt.ylabel('$(\lambda (t) - \lambda_f)/ (\lambda_i - \lambda_f)$', fontsize=24)
    plt.grid()
    # plt.legend(lines, labels, loc='best')
    lgd = plt.legend(lines, labels, bbox_to_anchor=(1.05, 1.0))
    plt.savefig(directory + '/protocol.pdf', bbox_extra_artists=(lgd,), bbox_inches='tight')
    plt.clf()

    lines = []
    fig1 = plt.figure()
    fig1.suptitle(r'$\mu = {}$'.format(mu), fontsize=24)
    for i in range(len(al)):
        lines += plt.plot(work0[i]/mu, std0[i]/mu, 'r', marker=markers[i % 13], label=r'$\alpha = {}$'.format(al[i]))
        # lines += plt.plot(work0[i], std0[i], 'r', marker=markers[i % 13], label=r'$\alpha = {}$'.format(al[i]))
    labels = [l.get_label() for l in lines]
    # plt.title(r'$\mu = {}$.format(mu)', fontsize=20)
    plt.xlabel('$\mu_w $', fontsize=24)
    plt.ylabel('$\sigma_w $', fontsize=24)
    plt.grid()
    # plt.legend(lines, labels, loc='best')
    lgd = plt.legend(lines, labels, bbox_to_anchor=(1.05, 1.0))
    plt.savefig(directory + '/pareto.pdf', bbox_extra_artists=(lgd,), bbox_inches='tight')
    plt.clf()


def save_data(data, directory):
    with open(directory + '/output_data', 'wb') as fp:
        pickle.dump(data, fp)


def read_data(directory):
    with open(directory + '/output_data', 'rb') as fp:
        output = pickle.load(fp)
    return output


def create_folders_single_trap():
    date = str(dat.date.today())
    CHECK_FOLDER = os.path.isdir('Pareto_front')
    if not CHECK_FOLDER:
        os.makedirs('Pareto_front')

    CHECK_FOLDER = os.path.isdir('Pareto_front/Single_trap_change_gamma')
    if not CHECK_FOLDER:
        os.makedirs('Pareto_front/Single_trap_change_gamma')

    CHECK_FOLDER = os.path.isdir('Pareto_front/Single_trap_change_gamma/' + date)
    if not CHECK_FOLDER:
        os.makedirs('Pareto_front/Single_trap_change_gamma/' + date)

    CHECK_FOLDER = os.path.isdir('Pareto_front/Single_trap_change_gamma/' + date + '/scaled_protocol')
    if not CHECK_FOLDER:
        os.makedirs('Pareto_front/Single_trap_change_gamma/' + date + '/scaled_protocol')

    # CHECK_FOLDER = os.path.isdir('Pareto_front/Single_trap_change_gamma/' + date + '/unscaled_protocol')
    # if not CHECK_FOLDER:
    #     os.makedirs('Pareto_front/Single_trap_change_gamma/' + date + '/unscaled_protocol')

    nx = 'x = ' + str(f_freq)
    n1 = ', ki = ' + str(ki_0)
    n2 = ', kf = ' + str(kf_0)
    nt = ', time = ' + str(time)
    nl = ', learn_rate = ' + str(learn_rate)
    nb = ', nbmc = ' + str(nbmc)
    nh = ', hyst_steps = ' + str(hyst_steps)
    folder_name = str(nx + n1 + n2 + nt + nl + nb + nh)
    l_r = 'learn_rate = ' + str(learn_rate) + ', Forward_hysteresis_1'
    print(folder_name)

    CHECK_FOLDER = os.path.isdir('Pareto_front/Single_trap_change_gamma/' + date + '/scaled_protocol/' + l_r)
    if not CHECK_FOLDER:
        os.makedirs('Pareto_front/Single_trap_change_gamma/' + date + '/scaled_protocol/' + l_r)

    try:
        os.mkdir('Pareto_front/Single_trap_change_gamma/' + date + '/scaled_protocol/' + l_r + '/' + folder_name)
        original = r'ode_two_trap.py'
        target = r'Pareto_front/Single_trap_change_gamma/' + date + '/scaled_protocol/' + l_r + '/' + folder_name + '/ode_two_trap.py'
        sh.copyfile(original, target)
    except OSError as error:
        print(error)

    return 'Pareto_front/Single_trap_change_gamma/' + date + '/scaled_protocol/' + l_r + '/' + folder_name

    # CHECK_FOLDER = os.path.isdir('Pareto_front/Single_trap_change_gamma/' + date + '/unscaled_protocol/' + l_r)
    # if not CHECK_FOLDER:
    #     os.makedirs('Pareto_front/Single_trap_change_gamma/' + date + '/unscaled_protocol/' + l_r)
    #
    # try:
    #     os.mkdir('Pareto_front/Single_trap_change_gamma/' + date + '/unscaled_protocol/' + l_r + '/' + folder_name)
    #     original = r'ode_two_trap.py'
    #     target = r'Pareto_front/Single_trap_change_gamma/' + date + '/unscaled_protocol/' + l_r + '/' + folder_name + '/ode_two_trap.py'
    #     sh.copyfile(original, target)
    # except OSError as error:
    #     print(error)
    #
    # return 'Pareto_front/Single_trap_change_gamma/' + date + '/unscaled_protocol/' + l_r + '/' + folder_name

def plot_all_cost_functions_for_mu(dir):
    output_array = []
    gammas = []
    length = 0
    for xx in gamma_matrix:
        # if (xx < 1.05) and (xx > 0.08):
        directory = dir + '/Mu = ' + str(xx)
        data = read_data(directory)
        output_array.append(np.asarray(data[3]))
        length = length + 1
        gammas.append(xx)
    colors = ['r', 'g', 'b', 'y', 'c', 'm']

    lines = []
    for i in range(length):
        # plt.plot(al, cost_func, ',', label=r'$Cost-function = \mathcal{J}_{\alpha}$')
        lines += plt.plot(al, output_array[i]/gammas[i], '.-', markersize=5,
                          label=r'$\mu = {}$'.format(gammas[i]))
        # lines += plt.plot(t2, (prtcl0_single[i] - kf_0) / (ki_0 - kf_0), colors[i % 6], label=r'$\alpha = {}$'.format(al[i]))
    labels = [l.get_label() for l in lines]
    plt.xlabel(r'$\alpha $', fontsize=24)
    plt.ylabel(r'$\mathcal{J}_{\alpha}$', fontsize=24)
    plt.grid()
    # plt.legend(lines, labels, loc='best')
    lgd = plt.legend(lines, labels, bbox_to_anchor=(1.05, 1.0))
    # plt.savefig(dir + '/cost_function_small_mu.pdf', bbox_extra_artists=(lgd,), bbox_inches='tight')
    plt.savefig(dir + '/cost_function_small_mu.pdf', bbox_extra_artists=(lgd,), bbox_inches='tight')
    plt.clf()
    cost_fn_data = []
    for i in range(length):
        cost_fn_data.append(output_array[i] / gamma_matrix[i])
    out_data = []
    out_data.append(al)
    out_data.append(cost_fn_data)
    with open(dir + '/all_cost_function_data', 'wb') as fp:
        pickle.dump(out_data, fp)


def plot_all_deriv_cost_function(dir):
    output_array = []
    d_cost_function = []
    gammas = []
    length = 0
    al_length = len(al)
    al_new = []
    for xx in gamma_matrix:
        # if (xx < 1.05) and (xx > 0.08):
        directory = dir + '/Mu = ' + str(xx)
        data = read_data(directory)
        output_array.append(np.asarray(data[3]))
        length = length + 1
        gammas.append(xx)
        d_cost_function.append([])
    for j in range(length):
        for i in range(al_length):
            if i == 0:
                d = (output_array[j][i + 1] - output_array[j][i]) / (al[i + 1] - al[i])
                d_cost_function[j].append(d)
            elif i == (al_length - 1):
                d = (output_array[j][i] - output_array[j][i - 1]) / (al[i] - al[i - 1])
                d_cost_function[j].append(d)
            else:
                # d = ((output_array[j][i + 1] - output_array[j][i-1]) / (al[i + 1] - al[i-1]) + (output_array[j][i + 1] - output_array[j][i]) / (al[i + 1] - al[i]) + (output_array[j][i] - output_array[j][i-1]) / (al[i] - al[i-1]))/3
                d = (output_array[j][i + 1] - output_array[j][i]) / (al[i + 1] - al[i])
                # d1 = (output_array[j][i + 1] - output_array[j][i]) * (al[i] - al[i-1]) / ((al[i + 1] - al[i]) * (al[i+1] - al[i-1]))
                # d2 = (output_array[j][i] - output_array[j][i -1]) * (al[i + 1] - al[i]) / ((al[i] - al[i - 1]) * (al[i+1] - al[i-1]))
                # # d = 0.5 * ((output_array[j][i + 1] - output_array[j][i]) / (al[i + 1] - al[i]) + (output_array[j][i] - output_array[j][i - 1]) / (al[i] - al[i - 1]))
                # d_cost_function[j].append(d1+d2)
                d_cost_function[j].append(d)
        # d_cost_function[j], a_n = smoothen_derivative(d_cost_function[j], al)
        # d_cost_function[j], a_n = smoothen_derivative(d_cost_function[j], a_n)
        # d_cost_function[j], a_n = smoothen_derivative(d_cost_function[j], a_n)
        # al_new.append(a_n)
        al_new.append(al)
            # d_cost_function[j][0] = d_cost_function[j][1]
            # d_cost_function[j][al_length-1] = d_cost_function[j][al_length-2]
    lines = []
    for i in range(length):
        # plt.plot(al, cost_func, ',', label=r'$Cost-function = \mathcal{J}_{\alpha}$')
        lines += plt.plot(al_new[i], d_cost_function[i] / gammas[i], '.-', markersize=5,
                          label=r'$\mu = {}$'.format(gammas[i]))
        # lines += plt.plot(t2, (prtcl0_single[i] - kf_0) / (ki_0 - kf_0), colors[i % 6], label=r'$\alpha = {}$'.format(al[i]))
    labels = [l.get_label() for l in lines]
    plt.xlabel(r'$\alpha $', fontsize=24)
    plt.ylabel(r'$\frac{d \mathcal{J}_{\alpha}}{d \alpha}$', fontsize=24)
    plt.grid()
    # plt.legend(lines, labels, loc='best')
    lgd = plt.legend(lines, labels, bbox_to_anchor=(1.05, 1.0))
    # plt.savefig(dir + '/cost_function_small_mu.pdf', bbox_extra_artists=(lgd,), bbox_inches='tight')
    plt.savefig(dir + '/derivative_cost_function_small_mu.pdf', bbox_extra_artists=(lgd,), bbox_inches='tight')
    plt.clf()
    der_cost_fn_data = []
    for i in range(length):
        der_cost_fn_data.append(d_cost_function[i] / gammas[i])
    out_data = []
    out_data.append(al_new)
    out_data.append(der_cost_fn_data)
    with open(dir + '/der_all_cost_function_data', 'wb') as fp:
        pickle.dump(out_data, fp)


def smoothen_derivative(d_a, al_new):
    for i in range(len(al)):
        if (i != 0 and i != len(al) - 1) and (0.3 < al[i] < 0.5):
            if d_a[i] > d_a[i+1] and d_a[i] > d_a[i-1]:
                d_a = np.delete(d_a, i)
                al_new = np.delete(al_new, i)
                # d_a[i] = 0.5*(d_a[i+1]+d_a[i-1])
            elif d_a[i] < d_a[i+1] and d_a[i] < d_a[i-1]:
                d_a = np.delete(d_a, i)
                al_new = np.delete(al_new, i)
                # d_a[i] = 0.5 * (d_a[i + 1] + d_a[i - 1])
            else:
                continue
    print(len(d_a), len(al_new))
    return d_a, al_new


def plot_hysterisis_loop(dir1, dir2):
    with open(dir1 + '/der_all_cost_function_data', 'rb') as fp:
        der_forward = pickle.load(fp)
    with open(dir2 + '/der_all_cost_function_data', 'rb') as fp:
        der_backward = pickle.load(fp)
    for i in range(len(gamma_matrix)):
        xx = gamma_matrix[i]
        directory1 = dir1 + '/Mu = ' + str(xx)
        directory2 = dir2 + '/Mu = ' + str(xx)
        fig1 = plt.figure()
        fig1.suptitle(r'$\mu = {}$'.format(gamma_matrix[i]), fontsize=24)
        plt.plot(der_backward[0], der_backward[1][i], '.-', markersize=5, label=r'$Backward-loop = \frac{d \mathcal{J}_{\alpha}}{d \alpha}$')
        plt.plot(der_forward[0], der_forward[1][i], '.-', markersize=5, label=r'$Forward-loop = \frac{d \mathcal{J}_{\alpha}}{d \alpha}$')
        # plt.plot(al, cost_func, '.', label=r'$Cost-function = \mathcal{J}_{\alpha}$')
        plt.legend(loc='best')
        plt.xlabel(r'$\alpha $', fontsize=24)
        plt.ylabel(r'$\frac{d \mathcal{J}_{\alpha}}{d \alpha}$', fontsize=24)
        plt.grid()
        fig1.set_size_inches(8, 4.5)
        plt.savefig(directory1 + '/hysterisis_loop.pdf')
        plt.savefig(directory2 + '/hysterisis_loop.pdf')
        plt.clf()

        fig1 = plt.figure()
        fig1.suptitle(r'$\mu = {}$'.format(gamma_matrix[i]), fontsize=24)
        plt.plot(der_backward[0], der_backward[1][i] - np.flip(der_forward[1][i], axis=0), '.-', markersize=5, label=r'$Loop-Difference = \frac{d \mathcal{J}_{\alpha}}{d \alpha}$')
        # plt.plot(al, cost_func, '.', label=r'$Cost-function = \mathcal{J}_{\alpha}$')
        plt.legend(loc='best')
        plt.xlabel(r'$\alpha $', fontsize=24)
        plt.ylabel(r'$\frac{d \mathcal{J}_{\alpha}}{d \alpha}$', fontsize=24)
        plt.grid()
        fig1.set_size_inches(8, 4.5)
        plt.savefig(directory1 + '/hysterisis_loop_difference.pdf')
        plt.savefig(directory2 + '/hysterisis_loop_difference.pdf')
        plt.clf()


def simulate_single_trap_class(directory, gamma_matrix):
    xx = gamma_matrix
    sub_folder_name = 'Mu = ' + str(xx)
    print('INITIALLY PASSED VALUE', xx)
    try:
        os.mkdir(directory + '/' + str(sub_folder_name))
    except OSError as error:
        print(error)
        sh.rmtree(directory + '/' + str(sub_folder_name))
        os.mkdir(directory + '/' + str(sub_folder_name))

    obj0 = SingleTrap(ki_1, kf_1, xx)
    output0 = obj0.simulate_pareto_single_trap()
    dir = directory + '/' + str(sub_folder_name)
    plot_data_recursively(output0, dir, xx)
    # plot_output_data(output0, dir)
    save_data(output0, dir)


# def simulate_single_trap_class_hysteresis(directory, hyst_steps_mat):
#     xx = hyst_steps_mat
#     sub_folder_name = 'hyst_step = ' + str(xx)
#     print('INITIALLY PASSED VALUE', xx)
#     try:
#         os.mkdir(directory + '/' + str(sub_folder_name))
#     except OSError as error:
#         print(error)
#         sh.rmtree(directory + '/' + str(sub_folder_name))
#         os.mkdir(directory + '/' + str(sub_folder_name))
#
#     obj0 = SingleTrap(ki_1, kf_1, xx)
#     output0 = obj0.simulate_pareto_single_trap()
#     dir = directory + '/' + str(sub_folder_name)
#     plot_data_recursively(output0, dir, xx)
#     # plot_output_data(output0, dir)
#     save_data(output0, dir)


if __name__ == '__main__':
    # plot_pareto()
    # plot_pareto_single_trap()
    start_time = ti.time()
    directory = create_folders_single_trap()
    pool = mp.Pool(mp.cpu_count())
    for l1 in gamma_matrix:
        pool.apply_async(simulate_single_trap_class, args=(directory, l1))
    # [pool.apply(simulate_single_trap_class, args=(directory, l1)) for l1 in gamma_matrix]
    pool.close()
    pool.join()
    plot_all_cost_functions_for_mu(directory)
    plot_all_deriv_cost_function(directory)
    print(mp.cpu_count())
    print(pool)
    # for xx in gamma_matrix:
    #     obj0 = SingleTrap(ki_1, kf_1, xx)
    #     obj0.multiprocess_simulate_pareto_run()
    #     output0 = obj0.output
    #     print('THE SHAPE', len(output0[0]))
    #     sub_folder_name = 'Mu = ' + str(xx)
    #     dir = directory + '/' + str(sub_folder_name)
    #     plot_data_recursively(output0, dir)
    #     # plot_output_data(output0, dir)
    #     save_data(output0, dir)
    print(' IMPLEMENTED WITH MULTI-PROCESS ')
    end_time = ti.time()
    hours, rem = divmod(end_time - start_time, 3600)
    minutes, seconds = divmod(rem, 60)
    print('THE TIME FOR PROCESS', "{:0>2}:{:0>2}:{:05.2f}".format(int(hours), int(minutes), seconds))

# if __name__ == '__main__':
#     d_f = 'Pareto_front/Single_trap_change_gamma/2021-08-02/scaled_protocol/learn_rate = 0.05, Forward_hysteresis_1/k0 = 5.0, k0 = 0.2, time = 1, learn_rate = 0.05, nbmc = 300000, hyst_steps = 50000'
#     d_b = 'Pareto_front/Single_trap_change_gamma/2021-08-02/scaled_protocol/learn_rate = 0.05, Reverse_hysteresis_1/k0 = 5.0, k0 = 0.2, time = 1, learn_rate = 0.05, nbmc = 300000, hyst_steps = 50000'
#     plot_all_cost_functions_for_mu(d_f)
#     plot_all_deriv_cost_function(d_f)
#     plot_hysterisis_loop(d_f, d_b)

