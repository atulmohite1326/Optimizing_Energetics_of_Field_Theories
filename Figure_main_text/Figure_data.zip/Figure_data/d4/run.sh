#!/bin/bash -l

#python ModelB.py 'N_64_T_1e-3' 64 0 1e-3 -1 1 1 1e1 1e-3 1e2 1e-1 1
python ModelA.py 'N_64_T_1e-3' 64 0 1e-2 1 1 0.5 1e-3 10 1e1 1e-2 1
ipython plot_movie_dens.py
