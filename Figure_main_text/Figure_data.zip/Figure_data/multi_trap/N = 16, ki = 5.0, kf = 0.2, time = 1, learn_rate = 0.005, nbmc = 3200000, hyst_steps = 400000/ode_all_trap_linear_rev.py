import numpy as np
from scipy.integrate import odeint
import matplotlib.pyplot as plt
import os
import shutil as sh
import pickle
import sys
import multiprocessing as mp
import time as ti
import multiprocessing as mp
import datetime as dat
from multiprocessing.pool import ThreadPool

i = 1
try:
    L = int(sys.argv[i]); i+=1                     # difference between ki_0 and kf_0
    ki_0 = float(sys.argv[i]); i+=1                # Number of lattice sites
    kf_0 = float(sys.argv[i]); i+=1                # Initial uniform density
    learn_rate = float(sys.argv[i]); i+=1          # Learning rate for SGD MC
    hyst_steps = int(sys.argv[i]); i+=1            # Number of hysterysis steps for SD
    mu = float(sys.argv[i]); i+=1                  # mu
    nbmc = 200000*L                                # Number of MC for SD
    time = 1
except:
    L = 8
    ki_0 = np.float(5.0)
    kf_0 = np.float(0.2)
    time = 1
    learn_rate = 0.005
    nbmc = 25
    hyst_steps = 1
    mu = 1.0
    print('No input given. Taking default values.')

# x = 0.5
#
# ki_0 = np.float(5.0)
# kf_0 = np.float(1.0)

ki_1 = np.float(ki_0)
kf_1 = np.float(kf_0)

# gamma_matrix = np.asarray([0.05, 0.1, 0.15, 0.2, 0.3, 0.4, 0.5, 0.6, 0.8, 1.0, 1.1, 1.2, 1.3, 1.4, 1.6, 2.0, 2.5, 4.0])

# gamma_matrix = np.asarray([1.0, 1.1, 1.2, 1.3, 1.4, 1.5, 1.6, 1.7, 1.8, 1.9, 2.0, 2.1, 2.2, 2.3, 2.4, 2.5, 2.6, 2.7, 2.8, 2.9, 3.0,3.2, 3.4, 3.6, 3.8, 4.0, 4.5])
gamma_matrix = np.asarray([mu])

f = np.fft.fftfreq(L*2)*2*np.pi
f_freq = np.flip(abs(f[L: 2*L]), axis=0)
print(f_freq)

# al = np.asarray([0.0, 0.05, 0.15, 0.25, 0.3, 0.32, 0.34, 0.36, 0.38, 0.4, 0.43, 0.47, 0.5, 0.53, 0.56, 0.58, 0.6, 0.62, 0.64, 0.7, 0.85, 1.0])

# al = np.asarray([0.0, 0.05, 0.15, 0.22, 0.27, 0.3, 0.32, 0.34, 0.36, 0.37, 0.38, 0.39, 0.4, 0.41, 0.42, 0.43, 0.44, 0.45, 0.46, 0.48, 0.5, 0.52, 0.54, 0.56, 0.58, 0.6, 0.65, 0.7, 0.85, 1.0])
# al_f = np.asarray([0.0, 0.1, 0.2, 0.3, 0.4, 0.50, 0.6, 0.7, 0.8, 0.9, 1.0])
# al_f = np.asarray([0.0, 0.05, 0.1, 0.15, 0.2, 0.22, 0.24, 0.25, 0.26, 0.27, 0.28, 0.3, 0.32, 0.35, 0.5, 0.7, 1.0])
al_f = np.asarray([0.0, 0.04, 0.07, 0.1, 0.12, 0.13, 0.14, 0.15, 0.16, 0.17, 0.18, 0.19, 0.2, 0.21, 0.22, 0.24, 0.27, 0.3, 0.35, 0.5, 0.7, 1.0])
# al_f = np.asarray([0.0, 0.7, 1.0])
al = np.flip(al_f, axis=0)
# al = np.asarray([0.0, 0.2, 0.3, 0.4, 0.45, 0.48, 0.51,  0.52, 0.53, 0.54, 0.55, 0.56, 0.57, 0.58, 0.59, 0.6, 0.61, 0.62, 0.63, 0.64, 0.65, 0.66, 0.74, 0.85, 1.0])
# al = np.asarray([1.0])

# hyst_steps_mat = np.asarray([1e3, 2e3, 4e3, 6e3, 8e3, 1e4, 2e4, 3e4, 4e4, 5e4])

class SingleTrap:
    def __init__(self, k_i, k_f, noise_str, dir):
        self.ki = k_i
        self.kf = k_f
        self.L = noise_str
        self.arr_ki = []
        self.arr_kf = []
        for q in f_freq:
            self.arr_ki.append(self.ki + q * q)
            self.arr_kf.append(self.kf + q * q)
            # print(self.arr_ki)
            # print(self.arr_kf)
            # print(np.asarray(self.arr_ki) - np.asarray(self.arr_kf))
        self.directory = dir
        self.result_list = []
        self.alpha_list = []
        self.output = []
        self.output.append([])
        self.output.append([])
        self.output.append([])
        self.output.append([])

    def simulate_pareto_multi_trap(self):
        sub_folder_name = 'Mu = ' + str(gamma_matrix[0])
        dir = self.directory + '/' + str(sub_folder_name)
        alpha_index = 0
        try:
            print(dir)
            with open(dir + '/output_data', 'rb') as fp:
                output = pickle.load(fp)
        except:
            print('HELLO')
        # try:
        #     print(dir)
        #     with open(dir + '/output_data', 'rb') as fp:
        #         output = pickle.load(fp)
        #     alpha_index = len(np.asarray(output[0]))
        #     print('HOW ARE ZOU')
        #     print(alpha_index, 'ALPHA_INDEX')
        #     prt_0 = np.asarray(output[2][alpha_index - 1])
        # except:
        #     output = []
        #     output.append([])
        #     output.append([])
        #     output.append([])
        #     print('I MA FINE')
        #     output.append([])
        #     output.append([])
        #     output.append([])
        #     prt_lst = []
        #     for i in range(L):
        #         prt_lst.append(np.random.uniform(self.L*self.arr_ki[i], self.L*self.arr_kf[i], time*100 + 1))
        #     prt_0 = np.asarray(prt_lst)
        output = []
        output.append([])
        output.append([])
        output.append([])
        # print('I MA FINE')
        output.append([])
        output.append([])
        output.append([])
        prt_lst = []
        for i in range(L):
            prt_lst.append(np.random.uniform(self.L*self.arr_ki[i], self.L*self.arr_kf[i], time*100 + 1))
        prt_0 = np.asarray(prt_lst)
        print(prt_0.shape)
        # prt_0 = np.asarray(np.random.uniform(self.L*self.ki, self.L*self.kf, (L, time*100 + 1)) + np.transpose(np.tile(self.L * f_freq *f_freq, (time*100 + 1, 1))))
        # prt_0 = []
        # for i in range(L):
        #     prt_0.append(np.asarray(np.random.uniform(self.L*(self.ki + f_freq[i]*f_freq[i]), self.L*(self.kf + f_freq[i]*f_freq[i]), time*100 + 1)))
        #     print(f_freq[i]*f_freq[i])

        # prt_0 = np.asarray(np.linspace(self.L*(self.ki + f_freq * f_freq), self.L* (self.kf + f_freq *f_freq), time*100 + 1))
        print(alpha_index)
        for i in range(alpha_index, len(al)):
            if i == 0:
                mc_steps = nbmc
            else:
                mc_steps = hyst_steps
            alpha = al[i]
            print(alpha)
            work, std_dev, prtcl0, cost_func, arr_f_m, arr_s_m = self.monte_carlo(prt_0, alpha, mc_steps) # mean work, standard deviation, optimum protocol
            output[0].append(work)
            output[1].append(std_dev)
            output[2].append(prtcl0)
            output[3].append(cost_func)
            output[4].append(arr_f_m)
            output[5].append(arr_s_m)
            prt_0 = prtcl0
            dir = self.directory + '/' + str(sub_folder_name)
            save_data(output, dir)
            plot_data_recursively(output, dir, self.L, i + 1)
        return output

    def multiprocess_monte_carlo(self, protocol, index):
        ki = self.arr_ki[index]
        kf = self.arr_kf[index]
        kl = max(ki, kf)
        j = np.random.randint(0, time * 100 + 1)
        protocol_new = np.asarray(protocol.copy())
        protocol_new[j] = protocol_new[j] + learn_rate * self.L * kl * np.random.normal(0, 1)
        protocol_new = abs(protocol_new)
        # solve ODE
        solution = self.solve_ode(protocol_new, index)
        # Compute work and variance and the cost function
        first_moment, second_moment = self.work_and_variance(solution, index)
        return first_moment, second_moment, protocol, protocol_new, index

    def monte_carlo(self, initial_protocol, alpha, mc_steps):
        print(initial_protocol.shape)
        protocol = initial_protocol.copy()
        previous_f_m, previous_s_m = 100*np.ones(L), 200 * np.ones(L)
        for i in range(L):
            first_moment, second_moment, protocol_old, protocol_new, index = self.multiprocess_monte_carlo(protocol[i], i)
            previous_f_m[i] = first_moment
            previous_s_m[i] = second_moment
        previous_cost, previous_work, previous_std = self.cost_fn_all(previous_f_m, previous_s_m, alpha)
        for i in range(mc_steps):
            # protocol_new = protocol.copy()
            prt_index = i % L
            first_moment, second_moment, protocol_old, protocol_new, index = self.multiprocess_monte_carlo(protocol[prt_index], prt_index)
            current_f_m, current_s_m = previous_f_m.copy(), previous_s_m.copy()
            current_f_m[index] = first_moment
            current_s_m[index] = second_moment
            current_cost, current_work, current_std = self.cost_fn_all(current_f_m, current_s_m, alpha)
            if current_cost < previous_cost:
                # accept the protocol change
                previous_cost, previous_work, previous_std = current_cost, current_work, current_std
                previous_f_m, previous_s_m = current_f_m, current_s_m
                protocol[index] = np.asarray(protocol_new.copy())
            protocol_time = protocol.copy()
        return previous_work, previous_std, protocol_time, previous_cost, previous_f_m, previous_s_m

    def dPdt(self, P, t, *args):
        w, x_2, w_2, x_2w, x0_2w, x_2x0_2, x_4, prtcl = P
        prtcl_ini, prtcl_final, initial_correl = args
        prtcl_dot = np.float(100.0 * (prtcl_final - prtcl_ini))
        dwdt = np.float(0.5 * prtcl_dot * x_2)
        dx_2dt = np.float(-2.0 * prtcl * x_2 + 2.0 * self.L)
        dw_2dt = np.float(prtcl_dot * x_2w)
        dx_2wdt = np.float(2.0 * w * self.L + 0.5 * prtcl_dot * x_4 - 2.0 * prtcl * x_2w)
        dx0_2wdt = np.float(0.5 * prtcl_dot * x_2x0_2)
        dx_2x0_2dt = np.float(-2.0 * prtcl * x_2x0_2 + 2.0 * initial_correl * self.L)
        dx_4dt = np.float(-4.0 * prtcl * x_4 + 12.0 * x_2 * self.L)
        dprodt = np.float(100.0 * (prtcl_final - prtcl_ini))
        return dwdt, dx_2dt, dw_2dt, dx_2wdt, dx0_2wdt, dx_2x0_2dt, dx_4dt, dprodt

    def solve_ode(self, given_protocol, index):
        ki = self.arr_ki[index]
        kf = self.arr_kf[index]
        prt = given_protocol
        t2 = np.linspace(0, 0.01, 10 + 1)
        w0 = 0.0
        x_20 = 1.0/ki
        w_20 = 0.0
        x_2w0 = 0.0
        x0_2w0 = 0.0
        x_2x0_20 = 3.0/(ki*ki)
        x_40 = 3.0/(ki*ki)
        prtcl0 = prt[0]
        temp_sol2 = w0, x_20, w_20, x_2w0, x0_2w0, x_2x0_20, x_40, prtcl0
        parameters = []
        for i in range(time * 100):
            parameters.append((prt[i], prt[i + 1], np.float(1/ki)))
        for i in range(time * 100):
            temp_sol3 = odeint(self.dPdt, temp_sol2, t2, args=parameters[i])
            if i == 0:
                sol2 = temp_sol3.copy()
            else:
                sol2 = np.vstack((sol2, temp_sol3[1:11, :]))
            temp_sol2 = tuple(temp_sol3[10, :])
        return sol2

    def work_and_variance(self, input, index):
        sh = input.shape
        ki = self.arr_ki[index]
        kf = self.arr_kf[index]
        delta_k0 = input[0, 7] - ki
        delta_kt = kf - input[sh[0]-1, 7]
        work = input[sh[0]-1, 0] + 0.5*delta_k0*input[0, 1] + 0.5*delta_kt*input[sh[0]-1, 1]
        variance = input[sh[0]-1, 2] + delta_k0*input[sh[0]-1, 4] + delta_kt*input[sh[0]-1, 3] + 0.25*(delta_k0*delta_k0*input[0, 6] + 2*delta_k0*delta_kt*input[sh[0]-1, 5] + delta_kt*delta_kt*input[sh[0]-1, 6])
        return work, variance

    def cost_fn_all(self, first_moment_array, second_moment_array, a):
        std_dev = np.sqrt(np.sum(second_moment_array - first_moment_array * first_moment_array))
        work = np.sum(first_moment_array)
        return a*work + (1 - a)*std_dev, work, std_dev

    def cost_fn(self, work, variance, a):
        standard_deviation = np.sqrt(variance - work*work)
        return a*work + (1 - a)*standard_deviation

    def __del__(self):
        print("Object deleted")

# def multiprocess_monte_carlo(self, protocol, ki, kf, i):
# def multiprocess_monte_carlo(data):
#     self = data.get('self')
#     protocol = data.get('protocol')
#     f_q = data.get('freq')
#     ki = self.ki + f_q*f_q
#     kf = self.kf + f_q*f_q
#     index = data.get('index')
#     # change random point of the protocol with a gaussian increment
#     j = np.random.randint(0, time * 100 + 1)
#     protocol_new = protocol.copy()
#     # protocol_new[j] = protocol_new[j] + learn_rate*(self.ki - self.kf)*self.L*np.random.normal(0, 1)
#     protocol_new[j] = protocol_new[j] + learn_rate * (ki - kf) * self.L * np.random.normal(0, 1)
#     protocol_new = abs(protocol_new)
#     # solve ODE
#     solution = self.solve_ode(protocol_new, ki, kf)
#     # Compute work and variance and the cost function
#     first_moment, second_moment = self.work_and_variance(solution, ki, kf)
#     return first_moment, second_moment, protocol, protocol_new, index

def compute_analytical_protocol(ki, kf, mu, time):
    sq_cf = np.sqrt(1 / kf)
    sq_ci = np.sqrt(1 / ki)
    t2 = np.linspace(0, time, time * 100 + 1)
    sq_C = sq_cf * t2 + sq_ci * (1 - t2)
    protocol = -(sq_cf - sq_ci)/(mu *time * sq_C) + 1/(sq_C * sq_C)
    # protocol = 1/(sq_C * sq_C)
    return protocol

def plot_data_recursively(output, directory, xx, len_al):
    work0 = np.asarray(output[0])
    std0 = np.asarray(output[1])
    prtcl0_single = np.asarray(output[2])
    cost_func = np.asarray(output[3])
    first_moment_ary = np.asarray(output[4])
    second_moment_ary = np.asarray(output[5])
    t2 = np.linspace(0, time, time * 100 + 1)
    t_i = np.linspace(-0.1, 0, 2)
    t_f = np.linspace(time, time + 0.1, 2)
    mu = xx
    markers = ['o', 's', 'p', '*', 'h', 'd', 'v', 'X', 's', 'p', '*', 'h', 'd']
    colors = ['r', 'g', 'b', 'y', 'c', 'm']

    print('PRINT, IT WAS HERE')

    # plot individual pareto front
    for f_i in range(len(f_freq)):
        lines = []
        fig1 = plt.figure()
        fig1.suptitle(r'$\mu = {}$'.format(mu), fontsize=24)
        for i in range(len_al):
            lines += plt.plot(first_moment_ary[i][f_i] / mu, np.sqrt(second_moment_ary[i][f_i] - first_moment_ary[i][f_i]*first_moment_ary[i][f_i]) / mu, 'r', marker=markers[i % 13],
                              label=r'$\alpha = {}$'.format(al[i]))
            # lines += plt.plot(work0[i], std0[i], 'r', marker=markers[i % 13], label=r'$\alpha = {}$'.format(al[i]))
        labels = [l.get_label() for l in lines]
        # plt.title(r'$\mu = {}$.format(mu)', fontsize=20)
        plt.xlabel('$\mu_w $', fontsize=24)
        plt.ylabel('$\sigma_w $', fontsize=24)
        plt.grid()
        # plt.legend(lines, labels, loc='best')
        lgd = plt.legend(lines, labels, bbox_to_anchor=(1.05, 1.0))
        plt.savefig(directory + '/pareto_' + str(f_i) + '.pdf', bbox_extra_artists=(lgd,), bbox_inches='tight')
        plt.clf()

    # plot individual cost_functions
    for f_i in range(len(f_freq)):
        cost = []
        fig1 = plt.figure()
        fig1.suptitle(r'$\mu = {}$'.format(mu), fontsize=24)
        for i in range(len_al):
            cost.append((al[i] * first_moment_ary[i][f_i] + (1 - al[i]) * np.sqrt(second_moment_ary[i][f_i] - first_moment_ary[i][f_i] * first_moment_ary[i][f_i]))/mu)
        plt.plot(al[0:len_al], cost, '.-', label=r'$Cost-function = \mathcal{J}_{\alpha}$')
        # plt.plot(al, cost_func, '.-', label=r'$Cost-function = \mathcal{J}_{\alpha}$')
        # plt.title(r'$\mu = {}$.format(mu)', fontsize=20)
        plt.legend(loc='best')
        plt.xlabel(r'$\alpha $', fontsize=24)
        plt.ylabel(r'$\mathcal{J}_{\alpha}$', fontsize=24)
        plt.grid()
        plt.savefig(directory + '/cost_function_' + str(f_i) + '.pdf')
        plt.clf()

    # plotting cost function
    fig1 = plt.figure()
    fig1.suptitle(r'$\mu = {}$'.format(mu), fontsize=24)
    plt.plot(al[0:len_al], cost_func/mu, '.-', label=r'$Cost-function = \mathcal{J}_{\alpha}$')
    # plt.plot(al, cost_func, '.-', label=r'$Cost-function = \mathcal{J}_{\alpha}$')
    # plt.title(r'$\mu = {}$.format(mu)', fontsize=20)
    plt.legend(loc='best')
    plt.xlabel(r'$\alpha $', fontsize=24)
    plt.ylabel(r'$\mathcal{J}_{\alpha}$', fontsize=24)
    plt.grid()
    plt.savefig(directory + '/cost_function.pdf')
    plt.clf()

    # plotting protocols
    for f_i in range(len(f_freq)):
        lines = []
        fig1 = plt.figure()
        fig1.suptitle(r'$\mu = {}, q = {}$'.format(mu, f_freq[f_i]), fontsize=24)
        for i in range(len_al):
            lines += plt.plot(t2, (prtcl0_single[i][f_i]/mu - kf_0 - f_freq[f_i]*f_freq[f_i])/(ki_0 - kf_0), colors[i % 6], label=r'$\alpha = {}$'.format(al[i]))
            # lines += plt.plot(t2, (prtcl0_single[i] - kf_0) / (ki_0 - kf_0), colors[i % 6], label=r'$\alpha = {}$'.format(al[i]))
        labels = [l.get_label() for l in lines]
        # plt.title(r'$\mu = {}$.format(mu)', fontsize=20)
        plt.plot(t_i, 1 * np.ones(2), '--')
        plt.plot(t_f, np.zeros(2), '--')
        plt.xlabel('t', fontsize=24)
        plt.ylabel('$(\lambda (t) - \lambda_f)/ (\lambda_i - \lambda_f)$', fontsize=24)
        plt.grid()
        # plt.legend(lines, labels, loc='best')
        lgd = plt.legend(lines, labels, bbox_to_anchor=(1.05, 1.0))
        plt.savefig(directory + '/protocol_' + str(f_i) + '.pdf', bbox_extra_artists=(lgd,), bbox_inches='tight')
        plt.clf()

    # plotting protocol * mu
    for f_i in range(len(f_freq)):
        lines = []
        fig1 = plt.figure()
        fig1.suptitle(r'$\mu = {}, q = {}$'.format(mu, f_freq[f_i]), fontsize=24)
        for i in range(len_al):
            lines += plt.plot(t2, (prtcl0_single[i][f_i] - mu*(kf_0 + f_freq[f_i]*f_freq[f_i])) / (ki_0 - kf_0), colors[i % 6],
                              label=r'$\alpha = {}$'.format(al[i]))
            # lines += plt.plot(t2, (prtcl0_single[i] - kf_0) / (ki_0 - kf_0), colors[i % 6], label=r'$\alpha = {}$'.format(al[i]))
        labels = [l.get_label() for l in lines]
        plt.plot(t_i, mu * np.ones(2), '--')
        plt.plot(t_f, np.zeros(2), '--')
        # plt.title(r'$\mu = {}$.format(mu)', fontsize=20)
        plt.xlabel('t', fontsize=24)
        plt.ylabel('$\mu*(\lambda (t) - \lambda_f)/ (\lambda_i - \lambda_f)$', fontsize=24)
        plt.grid()
        # plt.legend(lines, labels, loc='best')
        lgd = plt.legend(lines, labels, bbox_to_anchor=(1.05, 1.0))
        plt.savefig(directory + '/protocol*mu_' + str(f_i) + '.pdf', bbox_extra_artists=(lgd,), bbox_inches='tight')
        plt.clf()

    # plotting protocol
    for f_i in range(len(f_freq)):
        lines = []
        fig1 = plt.figure()
        fig1.suptitle(r'$\mu = {}, q = {}$'.format(mu, f_freq[f_i]), fontsize=24)
        for i in range(len_al):
            lines += plt.plot(t2, prtcl0_single[i][f_i]/mu, colors[i % 6],
                              label=r'$\alpha = {}$'.format(al[i]))
            # lines += plt.plot(t2, (prtcl0_single[i] - kf_0) / (ki_0 - kf_0), colors[i % 6], label=r'$\alpha = {}$'.format(al[i]))
        labels = [l.get_label() for l in lines]
        # plt.title(r'$\mu = {}$.format(mu)', fontsize=20)
        plt.plot(t_i, (ki_0 + f_freq[f_i]*f_freq[f_i])*np.ones(2), '--')
        plt.plot(t_f, (kf_0 + f_freq[f_i]*f_freq[f_i])*np.ones(2), '--')
        plt.xlabel('t', fontsize=24)
        plt.ylabel('$\lambda (t)$', fontsize=24)
        plt.grid()
        # plt.legend(lines, labels, loc='best')
        lgd = plt.legend(lines, labels, bbox_to_anchor=(1.05, 1.0))
        plt.savefig(directory + '/protocol_real' + str(f_i) + '.pdf', bbox_extra_artists=(lgd,), bbox_inches='tight')
        plt.clf()

    # plotting the pareto front
    lines = []
    fig1 = plt.figure()
    fig1.suptitle(r'$\mu = {}$'.format(mu), fontsize=24)
    for i in range(len_al):
        lines += plt.plot(work0[i]/mu, std0[i]/mu, 'r', marker=markers[i % 13], label=r'$\alpha = {}$'.format(al[i]))
        # lines += plt.plot(work0[i], std0[i], 'r', marker=markers[i % 13], label=r'$\alpha = {}$'.format(al[i]))
    labels = [l.get_label() for l in lines]
    # plt.title(r'$\mu = {}$.format(mu)', fontsize=20)
    plt.xlabel('$\mu_w $', fontsize=24)
    plt.ylabel('$\sigma_w $', fontsize=24)
    plt.grid()
    # plt.legend(lines, labels, loc='best')
    lgd = plt.legend(lines, labels, bbox_to_anchor=(1.05, 1.0))
    plt.savefig(directory + '/pareto.pdf', bbox_extra_artists=(lgd,), bbox_inches='tight')
    plt.clf()


def save_data(data, directory):
    with open(directory + '/output_data', 'wb') as fp:
        pickle.dump(data, fp)


def read_data(directory):
    with open(directory + '/output_data', 'rb') as fp:
        output = pickle.load(fp)
    return output


def create_folders_single_trap():
    date = str(dat.date.today())
    CHECK_FOLDER = os.path.isdir('Pareto_front')
    if not CHECK_FOLDER:
        os.makedirs('Pareto_front')

    CHECK_FOLDER = os.path.isdir('Pareto_front/multi_trap_change_gamma')
    if not CHECK_FOLDER:
        os.makedirs('Pareto_front/multi_trap_change_gamma')

    CHECK_FOLDER = os.path.isdir('Pareto_front/multi_trap_change_gamma/' + date)
    if not CHECK_FOLDER:
        os.makedirs('Pareto_front/multi_trap_change_gamma/' + date)

    CHECK_FOLDER = os.path.isdir('Pareto_front/multi_trap_change_gamma/' + date + '/scaled_protocol')
    if not CHECK_FOLDER:
        os.makedirs('Pareto_front/multi_trap_change_gamma/' + date + '/scaled_protocol')

    nx = 'N = ' + str(L)
    n1 = ', ki = ' + str(ki_0)
    n2 = ', kf = ' + str(kf_0)
    nt = ', time = ' + str(time)
    nl = ', learn_rate = ' + str(learn_rate)
    nb = ', nbmc = ' + str(nbmc)
    nh = ', hyst_steps = ' + str(hyst_steps)
    folder_name = str(nx + n1 + n2 + nt + nl + nb + nh)
    l_r = 'learn_rate = ' + str(learn_rate) + ', Reverse_hysteresis_linear'
    print(folder_name)

    CHECK_FOLDER = os.path.isdir('Pareto_front/multi_trap_change_gamma/' + date + '/scaled_protocol/' + l_r)
    if not CHECK_FOLDER:
        os.makedirs('Pareto_front/multi_trap_change_gamma/' + date + '/scaled_protocol/' + l_r)

    try:
        os.mkdir('Pareto_front/multi_trap_change_gamma/' + date + '/scaled_protocol/' + l_r + '/' + folder_name)
        original = r'ode_all_trap_linear.py'
        target = r'Pareto_front/multi_trap_change_gamma/' + date + '/scaled_protocol/' + l_r + '/' + folder_name + '/ode_all_trap_linear.py'
        sh.copyfile(original, target)
    except OSError as error:
        print(error)
    return 'Pareto_front/multi_trap_change_gamma/' + date + '/scaled_protocol/' + l_r + '/' + folder_name


def plot_all_cost_functions_for_mu(dir):
    output_array = []
    gammas = []
    length = 0
    for xx in gamma_matrix:
        # if (xx < 1.05) and (xx > 0.08):
        directory = dir + '/Mu = ' + str(xx)
        data = read_data(directory)
        output_array.append(np.asarray(data[3]))
        length = length + 1
        gammas.append(xx)
    colors = ['r', 'g', 'b', 'y', 'c', 'm']

    lines = []
    for i in range(length):
        # plt.plot(al, cost_func, ',', label=r'$Cost-function = \mathcal{J}_{\alpha}$')
        lines += plt.plot(al, output_array[i]/gammas[i], '.-', markersize=5,
                          label=r'$\mu = {}$'.format(gammas[i]))
        # lines += plt.plot(t2, (prtcl0_single[i] - kf_0) / (ki_0 - kf_0), colors[i % 6], label=r'$\alpha = {}$'.format(al[i]))
    labels = [l.get_label() for l in lines]
    plt.xlabel(r'$\alpha $', fontsize=24)
    plt.ylabel(r'$\mathcal{J}_{\alpha}$', fontsize=24)
    plt.grid()
    # plt.legend(lines, labels, loc='best')
    lgd = plt.legend(lines, labels, bbox_to_anchor=(1.05, 1.0))
    # plt.savefig(dir + '/cost_function_small_mu.pdf', bbox_extra_artists=(lgd,), bbox_inches='tight')
    plt.savefig(dir + '/cost_function_small_mu.pdf', bbox_extra_artists=(lgd,), bbox_inches='tight')
    plt.clf()
    cost_fn_data = []
    for i in range(length):
        cost_fn_data.append(output_array[i] / gamma_matrix[i])
    out_data = []
    out_data.append(al)
    out_data.append(cost_fn_data)
    with open(dir + '/all_cost_function_data', 'wb') as fp:
        pickle.dump(out_data, fp)


def plot_all_deriv_cost_function(dir):
    output_array = []
    d_cost_function = []
    gammas = []
    length = 0
    al_length = len(al)
    al_new = []
    for xx in gamma_matrix:
        # if (xx < 1.05) and (xx > 0.08):
        directory = dir + '/Mu = ' + str(xx)
        data = read_data(directory)
        output_array.append(np.asarray(data[3]))
        length = length + 1
        gammas.append(xx)
        d_cost_function.append([])
    for j in range(length):
        for i in range(al_length):
            if i == 0:
                d = (output_array[j][i + 1] - output_array[j][i]) / (al[i + 1] - al[i])
                d_cost_function[j].append(d)
            elif i == (al_length - 1):
                d = (output_array[j][i] - output_array[j][i - 1]) / (al[i] - al[i - 1])
                d_cost_function[j].append(d)
            else:
                # d = ((output_array[j][i + 1] - output_array[j][i-1]) / (al[i + 1] - al[i-1]) + (output_array[j][i + 1] - output_array[j][i]) / (al[i + 1] - al[i]) + (output_array[j][i] - output_array[j][i-1]) / (al[i] - al[i-1]))/3
                d = (output_array[j][i + 1] - output_array[j][i]) / (al[i + 1] - al[i])
                # d1 = (output_array[j][i + 1] - output_array[j][i]) * (al[i] - al[i-1]) / ((al[i + 1] - al[i]) * (al[i+1] - al[i-1]))
                # d2 = (output_array[j][i] - output_array[j][i -1]) * (al[i + 1] - al[i]) / ((al[i] - al[i - 1]) * (al[i+1] - al[i-1]))
                # # d = 0.5 * ((output_array[j][i + 1] - output_array[j][i]) / (al[i + 1] - al[i]) + (output_array[j][i] - output_array[j][i - 1]) / (al[i] - al[i - 1]))
                # d_cost_function[j].append(d1+d2)
                d_cost_function[j].append(d)
        # d_cost_function[j], a_n = smoothen_derivative(d_cost_function[j], al)
        # d_cost_function[j], a_n = smoothen_derivative(d_cost_function[j], a_n)
        # d_cost_function[j], a_n = smoothen_derivative(d_cost_function[j], a_n)
        # al_new.append(a_n)
        al_new.append(al)
            # d_cost_function[j][0] = d_cost_function[j][1]
            # d_cost_function[j][al_length-1] = d_cost_function[j][al_length-2]
    lines = []
    for i in range(length):
        # plt.plot(al, cost_func, ',', label=r'$Cost-function = \mathcal{J}_{\alpha}$')
        lines += plt.plot(al_new[i], d_cost_function[i] / gammas[i], '.-', markersize=5,
                          label=r'$\mu = {}$'.format(gammas[i]))
        # lines += plt.plot(t2, (prtcl0_single[i] - kf_0) / (ki_0 - kf_0), colors[i % 6], label=r'$\alpha = {}$'.format(al[i]))
    labels = [l.get_label() for l in lines]
    plt.xlabel(r'$\alpha $', fontsize=24)
    plt.ylabel(r'$\frac{d \mathcal{J}_{\alpha}}{d \alpha}$', fontsize=24)
    plt.grid()
    # plt.legend(lines, labels, loc='best')
    lgd = plt.legend(lines, labels, bbox_to_anchor=(1.05, 1.0))
    # plt.savefig(dir + '/cost_function_small_mu.pdf', bbox_extra_artists=(lgd,), bbox_inches='tight')
    plt.savefig(dir + '/derivative_cost_function_small_mu.pdf', bbox_extra_artists=(lgd,), bbox_inches='tight')
    plt.clf()
    der_cost_fn_data = []
    for i in range(length):
        der_cost_fn_data.append(d_cost_function[i] / gammas[i])
    out_data = []
    out_data.append(al_new)
    out_data.append(der_cost_fn_data)
    with open(dir + '/der_all_cost_function_data', 'wb') as fp:
        pickle.dump(out_data, fp)


def smoothen_derivative(d_a, al_new):
    for i in range(len(al)):
        if (i != 0 and i != len(al) - 1) and (0.3 < al[i] < 0.5):
            if d_a[i] > d_a[i+1] and d_a[i] > d_a[i-1]:
                d_a = np.delete(d_a, i)
                al_new = np.delete(al_new, i)
                # d_a[i] = 0.5*(d_a[i+1]+d_a[i-1])
            elif d_a[i] < d_a[i+1] and d_a[i] < d_a[i-1]:
                d_a = np.delete(d_a, i)
                al_new = np.delete(al_new, i)
                # d_a[i] = 0.5 * (d_a[i + 1] + d_a[i - 1])
            else:
                continue
    print(len(d_a), len(al_new))
    return d_a, al_new


def plot_hysterisis_loop(dir1, dir2):
    with open(dir1 + '/der_all_cost_function_data', 'rb') as fp:
        der_forward = pickle.load(fp)
    with open(dir2 + '/der_all_cost_function_data', 'rb') as fp:
        der_backward = pickle.load(fp)
    for i in range(len(gamma_matrix)):
        xx = gamma_matrix[i]
        directory1 = dir1 + '/Mu = ' + str(xx)
        directory2 = dir2 + '/Mu = ' + str(xx)
        fig1 = plt.figure()
        fig1.suptitle(r'$\mu = {}$'.format(gamma_matrix[i]), fontsize=24)
        plt.plot(der_backward[0], der_backward[1][i], '.-', markersize=5, label=r'$Backward-loop = \frac{d \mathcal{J}_{\alpha}}{d \alpha}$')
        plt.plot(der_forward[0], der_forward[1][i], '.-', markersize=5, label=r'$Forward-loop = \frac{d \mathcal{J}_{\alpha}}{d \alpha}$')
        # plt.plot(al, cost_func, '.', label=r'$Cost-function = \mathcal{J}_{\alpha}$')
        plt.legend(loc='best')
        plt.xlabel(r'$\alpha $', fontsize=24)
        plt.ylabel(r'$\frac{d \mathcal{J}_{\alpha}}{d \alpha}$', fontsize=24)
        plt.grid()
        fig1.set_size_inches(8, 4.5)
        plt.savefig(directory1 + '/hysterisis_loop.pdf')
        plt.savefig(directory2 + '/hysterisis_loop.pdf')
        plt.clf()

        fig1 = plt.figure()
        fig1.suptitle(r'$\mu = {}$'.format(gamma_matrix[i]), fontsize=24)
        plt.plot(der_backward[0], der_backward[1][i] - np.flip(der_forward[1][i], axis=0), '.-', markersize=5, label=r'$Loop-Difference = \frac{d \mathcal{J}_{\alpha}}{d \alpha}$')
        # plt.plot(al, cost_func, '.', label=r'$Cost-function = \mathcal{J}_{\alpha}$')
        plt.legend(loc='best')
        plt.xlabel(r'$\alpha $', fontsize=24)
        plt.ylabel(r'$\frac{d \mathcal{J}_{\alpha}}{d \alpha}$', fontsize=24)
        plt.grid()
        fig1.set_size_inches(8, 4.5)
        plt.savefig(directory1 + '/hysterisis_loop_difference.pdf')
        plt.savefig(directory2 + '/hysterisis_loop_difference.pdf')
        plt.clf()


def simulate_single_trap_class(directory, gamma_matrix):
    xx = gamma_matrix
    sub_folder_name = 'Mu = ' + str(xx)
    print('INITIALLY PASSED VALUE', xx)
    try:
        os.mkdir(directory + '/' + str(sub_folder_name))
    except OSError as error:
        print(error)
        sh.rmtree(directory + '/' + str(sub_folder_name))
        os.mkdir(directory + '/' + str(sub_folder_name))

    obj0 = SingleTrap(ki_1, kf_1, xx, directory)
    output0 = obj0.simulate_pareto_multi_trap()
    dir = directory + '/' + str(sub_folder_name)
    plot_data_recursively(output0, dir, xx, len(al))
    # plot_output_data(output0, dir)
    save_data(output0, dir)


if __name__ == '__main__':
    start_time_1 = ti.time()
    directory = create_folders_single_trap()
    start_time = ti.time()
    pool = mp.Pool(mp.cpu_count())
    simulate_single_trap_class(directory, gamma_matrix[0])
    end_time = ti.time()
    # for l1 in gamma_matrix:
    #     pool.apply_async(simulate_single_trap_class, args=(directory, l1))
    # [pool.apply(simulate_single_trap_class, args=(directory, l1)) for l1 in gamma_matrix]
    pool.close()
    pool.join()
    plot_all_cost_functions_for_mu(directory)
    plot_all_deriv_cost_function(directory)
    print(mp.cpu_count())
    print(pool)
    print(' IMPLEMENTED WITH MULTI-PROCESS ')
    end_time_1 = ti.time()
    hours, rem = divmod(end_time - start_time, 3600)
    minutes, seconds = divmod(rem, 60)
    print('THE TIME FOR COMPUTATION', "{:0>2}:{:0>2}:{:05.2f}".format(int(hours), int(minutes), seconds))
    hours, rem = divmod(end_time_1 - start_time_1, 3600)
    minutes, seconds = divmod(rem, 60)
    print('THE TIME FOR PROCESS', "{:0>2}:{:0>2}:{:05.2f}".format(int(hours), int(minutes), seconds))

# if __name__ == '__main__':
#     d_f = 'Pareto_front/Single_trap_change_gamma/2021-08-02/scaled_protocol/learn_rate = 0.05, Forward_hysteresis_1/k0 = 5.0, k0 = 0.2, time = 1, learn_rate = 0.05, nbmc = 300000, hyst_steps = 50000'
#     d_b = 'Pareto_front/Single_trap_change_gamma/2021-08-02/scaled_protocol/learn_rate = 0.05, Reverse_hysteresis_1/k0 = 5.0, k0 = 0.2, time = 1, learn_rate = 0.05, nbmc = 300000, hyst_steps = 50000'
#     plot_all_cost_functions_for_mu(d_f)
#     plot_all_deriv_cost_function(d_f)
#     plot_hysterisis_loop(d_f, d_b)

# if __name__ == '__main__':
#     dir = 'Pareto_front/multi_trap_change_gamma/2021-08-31/scaled_protocol/learn_rate = 0.005, Reverse_hysteresis_linear/N = 4, ki = 5.0, kf = 0.2, time = 1, learn_rate = 0.005, nbmc = 300000, hyst_steps = 100000/Mu = 1.0'
#     dir = 'Pareto_front/multi_trap_change_gamma/2021-08-31/scaled_protocol/learn_rate = 0.005, Reverse_hysteresis_linear/N = 4, ki = 5.0, kf = 0.2, time = 1, learn_rate = 0.005, nbmc = 600000, hyst_steps = 100000/Mu = 4.0'
#     dir = 'Pareto_front/multi_trap_change_gamma/2021-08-31/scaled_protocol/learn_rate = 0.005, Reverse_hysteresis_linear/N = 4, ki = 5.0, kf = 0.2, time = 1, learn_rate = 0.005, nbmc = 600000, hyst_steps = 200000/Mu = 4.0'
#     dir = 'Pareto_front/multi_trap_change_gamma/2021-08-31/scaled_protocol/learn_rate = 0.005, Reverse_hysteresis_linear/N = 8, ki = 5.0, kf = 0.2, time = 1, learn_rate = 0.005, nbmc = 1200000, hyst_steps = 100000/Mu = 4.0'
#     # dir = 'Pareto_front/multi_trap_change_gamma/2021-08-31/scaled_protocol/learn_rate = 0.005, Reverse_hysteresis_linear/N = 8, ki = 5.0, kf = 0.2, time = 1, learn_rate = 0.005, nbmc = 1200000, hyst_steps = 200000/Mu = 4.0'
#     # dir = 'Pareto_front/multi_trap_change_gamma/2021-08-31/scaled_protocol/learn_rate = 0.005, Reverse_hysteresis_linear/N = 16, ki = 5.0, kf = 0.2, time = 1, learn_rate = 0.005, nbmc = 2400000, hyst_steps = 200000/Mu = 4.0'
#     # dir = 'Pareto_front/multi_trap_change_gamma/2021-08-31/scaled_protocol/learn_rate = 0.005, Reverse_hysteresis_linear/N = 16, ki = 5.0, kf = 0.2, time = 1, learn_rate = 0.005, nbmc = 2400000, hyst_steps = 300000/Mu = 4.0'
#     output = read_data(dir)
#     mu = 4.0
#     # plot_data_recursively(output, dir, mu)
#
#     protocol_set = output[2][0]
#     t2 = np.linspace(0, time, time * 100 + 1)
#
#     for i in range(len(f_freq)):
#         analytical_protocol = compute_analytical_protocol(ki_0 + f_freq[i]*f_freq[i], kf_0 + f_freq[i]*f_freq[i], mu, 1)
#         print(analytical_protocol.shape)
#         print(protocol_set.shape)
#         fig1 = plt.figure()
#         fig1.suptitle(r'$\mu = {}$'.format(mu), fontsize=24)
#         plt.plot(t2, protocol_set[i]/mu, '-', label=r'$numerical-expr$')
#         plt.plot(t2, analytical_protocol, '-', label=r'$analytical-expr$')
#         plt.legend(loc='best')
#         plt.xlabel('t', fontsize=24)
#         plt.ylabel('$\lambda (t)$', fontsize=24)
#         plt.grid()
#         plt.savefig(dir + '/analytical_vs_numerical_protocol' + str(i) + '.pdf')
#         plt.clf()

